class Person0{}
class Student0 extends Person0{}
class Researcher extends Person0{}
class Professor extends Researcher{}

public class InstanceOfEx {

	static void print(Person0 p) {
		if(p instanceof Person0)
			System.out.println("Person0");
		if(p instanceof Student0)
			System.out.println("Student0");
		if(p instanceof Researcher)
			System.out.println("Researcher");
		if(p instanceof Professor)
			System.out.println("Professor");
		System.out.println();
	}
	public static void main(String[] args) {
		
		System.out.println("new Student() -> \t");	print(new Student0());
		System.out.println("new Researcher() -> \t");	print(new Researcher());
		System.out.println("new Professor() -> \t");	print(new Professor());
	}

}
