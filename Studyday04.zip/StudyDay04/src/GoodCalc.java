
public class GoodCalc extends Calculator {

	@Override
	public int add(int a, int b) {
		
		return a+b;
	}

	@Override
	public int subtract(int a, int b) {
		// TODO Auto-generated method stub
		return a - b;
	}

	@Override
	public double averager(int[] a) {
		// TODO Auto-generated method stub
		double sum =0;
		for (int i = 0; i < a.length; i++) {
			sum+=a[i];
		}
		return sum/a.length;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GoodCalc gc = new GoodCalc();
		System.out.println(gc.add(2, 3));
		System.out.println(gc.subtract(4, 1));
		System.out.println(gc.averager(new int [] {2,3,4}));

	}

}
